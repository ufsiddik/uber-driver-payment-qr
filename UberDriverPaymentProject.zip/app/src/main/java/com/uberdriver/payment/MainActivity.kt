package com.uberdriver.payment

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val upi = "8116295714-7@ybl"
    private val remarks = "Uber"
    private val prefs by lazy { getSharedPreferences("transactions", MODE_PRIVATE) }
    private lateinit var amount: EditText
    private lateinit var qr: ImageView
    private lateinit var done: Button

    data class Transaction(val id: String, val amount: Double, val time: Long)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }

    private fun loadTransactions(): MutableList<Transaction> {
        val list = mutableListOf<Transaction>()
        val a = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            list.add(Transaction(o.getString("id"), o.getDouble("amount"), o.getLong("time")))
        }
        return list
    }

    private fun saveTransaction(t: Transaction) {
        val a = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        a.put(JSONObject().apply { put("id", t.id); put("amount", t.amount); put("time", t.time) })
        prefs.edit().putString("items", a.toString()).apply()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        val title = TextView(this).apply { text="Uber Driver Payment"; textSize=28f; setPadding(0,0,0,24) }
        amount = EditText(this).apply { hint="Amount to receive (₹)"; inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val generate = Button(this).apply { text="Generate QR" }
        qr = ImageView(this).apply { adjustViewBounds=true; visibility=View.GONE }
        done = Button(this).apply { text="Payment Done"; visibility=View.GONE }
        val reports = Button(this).apply { text="Reports" }

        generate.setOnClickListener {
            val a=amount.text.toString().toDoubleOrNull()
            if(a==null || a<=0){ amount.error="Enter a valid amount"; return@setOnClickListener }
            val uri="upi://pay?pa=$upi&pn=Uber%20Driver&am=${"%.2f".format(Locale.US,a)}&cu=INR&tn=$remarks"
            qr.setImageBitmap(makeQr(uri)); qr.visibility=View.VISIBLE; done.visibility=View.VISIBLE; done.tag=a
        }
        done.setOnClickListener {
            val a=done.tag as? Double ?: return@setOnClickListener
            val now=System.currentTimeMillis()
            val id="TXN-"+SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(Date(now))
            saveTransaction(Transaction(id,a,now))
            Toast.makeText(this,"Transaction saved locally",Toast.LENGTH_SHORT).show()
            try { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("uberdriver://"))) }
            catch(_:Exception) { try { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://drivers.uber.com/"))) } catch(_:Exception){} }
        }
        reports.setOnClickListener { showReports() }

        root.addView(title); root.addView(amount); root.addView(generate)
        root.addView(qr,LinearLayout.LayoutParams(-1,420)); root.addView(done); root.addView(reports)
        setContentView(root)
    }

    private fun showReports() {
        val list=loadTransactions()
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        root.addView(TextView(this).apply { text="Payment Reports"; textSize=28f })
        root.addView(TextView(this).apply { text="Transactions: ${list.size}\nTotal collected: ₹${"%.2f".format(list.sumOf{it.amount})}"; textSize=19f; setPadding(0,20,0,20) })
        list.asReversed().forEach { t ->
            root.addView(TextView(this).apply { text="${t.id} • ₹${"%.2f".format(t.amount)}\n${SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.US).format(Date(t.time))}"; textSize=16f; setPadding(0,10,0,10) })
        }
        root.addView(Button(this).apply { text="Back"; setOnClickListener{showHome()} })
        setContentView(root)
    }

    private fun makeQr(text:String):Bitmap {
        val m:BitMatrix=MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,600,600)
        val bm=Bitmap.createBitmap(600,600,Bitmap.Config.RGB_565)
        for(x in 0 until 600) for(y in 0 until 600) bm.setPixel(x,y,if(m[x,y]) Color.BLACK else Color.WHITE)
        return bm
    }
}
