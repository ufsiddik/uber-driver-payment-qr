package com.uberdriver.payment

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val upi = "8116295714-7@ybl"
    private val remark = "Uber"
    private val prefs by lazy { getSharedPreferences("driver_pay", MODE_PRIVATE) }
    private val black = Color.rgb(20,20,20)
    private val gray = Color.rgb(105,105,105)
    private val light = Color.rgb(246,246,246)
    private val green = Color.rgb(22,125,72)
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(b:Bundle?) { super.onCreate(b); showCollect() }

    private fun tv(s:String,size:Float,color:Int=black,bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size; setTextColor(color)
        if(bold) setTypeface(typeface,android.graphics.Typeface.BOLD)
    }
    private fun btn(s:String,bg:Int,fg:Int=Color.WHITE)=Button(this).apply {
        text=s; textSize=16f; setTextColor(fg); isAllCaps=false
        setTypeface(typeface,android.graphics.Typeface.BOLD)
        backgroundTintList=ColorStateList.valueOf(bg); minHeight=dp(54); stateListAnimator=null
    }
    private fun card()=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(18)); setBackgroundColor(light)
    }

    private fun showCollect() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(20),dp(18),dp(20),dp(12)) }
        val scroll=ScrollView(this)
        val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,0,0,dp(20)) }

        val top=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        top.addView(tv("DRIVER PAY",20f,black,true),LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(tv("  UPI  ",12f,Color.WHITE,true).apply { setBackgroundColor(black); setPadding(dp(7),dp(5),dp(7),dp(5)) })
        content.addView(top)
        content.addView(tv("Collect payment",30f,black,true).apply { setPadding(0,dp(22),0,dp(4)) })
        content.addView(tv("Enter the amount you want to receive",15f,gray))

        val amountBox=card()
        val amount=EditText(this).apply {
            hint="₹ 0"; textSize=38f; setTextColor(black); setHintTextColor(Color.LTGRAY); gravity=Gravity.CENTER
            inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            background=null
        }
        amountBox.addView(amount,LinearLayout.LayoutParams(-1,dp(72)))
        content.addView(amountBox,LinearLayout.LayoutParams(-1,dp(106)).apply { topMargin=dp(18) })

        val quick=LinearLayout(this).apply { gravity=Gravity.CENTER }
        listOf(100,200,500,1000).forEach { value ->
            val q=btn("₹$value",light,black)
            q.setOnClickListener { amount.setText(value.toString()); amount.setSelection(amount.length()) }
            quick.addView(q,LinearLayout.LayoutParams(0,dp(48),1f).apply { marginStart=dp(3); marginEnd=dp(3) })
        }
        content.addView(quick,LinearLayout.LayoutParams(-1,dp(54)).apply { topMargin=dp(12) })

        val info=card()
        info.addView(tv("PAYMENT DETAILS",12f,gray,true))
        info.addView(tv("UPI ID",13f,gray).apply { setPadding(0,dp(14),0,2) })
        info.addView(tv(upi,16f,black,true))
        info.addView(tv("Remark",13f,gray).apply { setPadding(0,dp(12),0,2) })
        info.addView(tv(remark,16f,black,true))
        content.addView(info,LinearLayout.LayoutParams(-1,dp(138)).apply { topMargin=dp(20) })

        val generate=btn("Generate QR",black)
        content.addView(generate,LinearLayout.LayoutParams(-1,dp(58)).apply { topMargin=dp(20) })
        val qr=ImageView(this).apply { adjustViewBounds=true; visibility=View.GONE; setPadding(dp(24),dp(18),dp(24),dp(18)) }
        content.addView(qr,LinearLayout.LayoutParams(-1,dp(330)))
        val done=btn("✓  Payment Done",green); done.visibility=View.GONE
        content.addView(done,LinearLayout.LayoutParams(-1,dp(58)))
        content.addView(tv("Records your confirmation locally; it does not verify the bank payment.",12f,gray).apply {
            gravity=Gravity.CENTER; visibility=View.GONE; tag="note"
        })

        generate.setOnClickListener {
            val v=amount.text.toString().toDoubleOrNull()
            if(v==null || v<=0){ amount.error="Enter a valid amount"; return@setOnClickListener }
            val uri="upi://pay?pa=$upi&pn=Driver%20Pay&am=${"%.2f".format(Locale.US,v)}&cu=INR&tn=$remark"
            qr.setImageBitmap(makeQr(uri)); qr.visibility=View.VISIBLE; done.visibility=View.VISIBLE
            generate.text="Regenerate QR"; done.tag=v
        }
        done.setOnClickListener {
            val v=done.tag as? Double ?: return@setOnClickListener
            saveTx(v); Toast.makeText(this,"Payment saved",Toast.LENGTH_SHORT).show(); openUberDriver()
        }

        scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); root.addView(bottomNav(0)); setContentView(root)
    }

    private fun bottomNav(selected:Int)=LinearLayout(this).apply {
        orientation=LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE); setPadding(0,dp(6),0,0)
        val a=btn("Collect",if(selected==0)black else light,if(selected==0)Color.WHITE else black)
        val b=btn("Reports",if(selected==1)black else light,if(selected==1)Color.WHITE else black)
        a.setOnClickListener{showCollect()}; b.setOnClickListener{showReports()}
        addView(a,LinearLayout.LayoutParams(0,dp(54),1f).apply{marginEnd=dp(5)})
        addView(b,LinearLayout.LayoutParams(0,dp(54),1f).apply{marginStart=dp(5)})
    }

    private fun saveTx(amount:Double) {
        val arr=try{org.json.JSONArray(prefs.getString("items","[]"))}catch(_:Exception){org.json.JSONArray()}
        val now=System.currentTimeMillis()
        arr.put(org.json.JSONObject().apply {
            put("id","TXN-"+SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(Date(now)))
            put("amount",amount); put("time",now)
        })
        prefs.edit().putString("items",arr.toString()).apply()
    }
    private data class Tx(val id:String,val amount:Double,val time:Long)
    private fun readTx():List<Tx>{
        val a=try{org.json.JSONArray(prefs.getString("items","[]"))}catch(_:Exception){org.json.JSONArray()}
        val l=mutableListOf<Tx>()
        for(i in 0 until a.length()){val o=a.getJSONObject(i);l.add(Tx(o.getString("id"),o.getDouble("amount"),o.getLong("time")))}
        return l
    }

    private fun showReports() {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE);setPadding(dp(20),dp(18),dp(20),dp(12))}
        val scroll=ScrollView(this)
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        content.addView(tv("Payment reports",30f,black,true))
        content.addView(tv("Your locally saved collections",15f,gray).apply{setPadding(0,dp(4),0,dp(20))})
        val list=readTx()
        val key=SimpleDateFormat("yyyyMMdd",Locale.US)
        val today=list.filter{key.format(Date(it.time))==key.format(Date())}
        val stats=LinearLayout(this)
        val c1=card(); c1.addView(tv("TODAY",12f,gray,true)); c1.addView(tv("₹${"%.0f".format(today.sumOf{it.amount})}",25f,black,true))
        val c2=card(); c2.addView(tv("PAYMENTS",12f,gray,true)); c2.addView(tv(today.size.toString(),25f,black,true))
        stats.addView(c1,LinearLayout.LayoutParams(0,dp(100),1f).apply{marginEnd=dp(5)})
        stats.addView(c2,LinearLayout.LayoutParams(0,dp(100),1f).apply{marginStart=dp(5)})
        content.addView(stats)
        content.addView(tv("TRANSACTIONS",12f,gray,true).apply{setPadding(0,dp(24),0,dp(10))})
        if(list.isEmpty()) content.addView(card().apply{gravity=Gravity.CENTER;addView(tv("No payments yet",18f,black,true));addView(tv("Completed payments will appear here.",13f,gray).apply{gravity=Gravity.CENTER})},LinearLayout.LayoutParams(-1,dp(120)))
        else list.asReversed().forEach{t->
            val row=card(); val line=LinearLayout(this)
            line.addView(tv("₹${"%.2f".format(t.amount)}",20f,black,true),LinearLayout.LayoutParams(0,-2,1f))
            line.addView(tv(SimpleDateFormat("dd MMM, hh:mm a",Locale.US).format(Date(t.time)),12f,gray))
            row.addView(line); row.addView(tv(t.id,12f,gray).apply{setPadding(0,dp(6),0,0)})
            content.addView(row,LinearLayout.LayoutParams(-1,dp(88)).apply{topMargin=dp(7)})
        }
        scroll.addView(content);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));root.addView(bottomNav(1));setContentView(root)
    }

    private fun openUberDriver(){
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setPackage("com.ubercab.driver")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Uber Driver app is not installed", Toast.LENGTH_LONG).show()
        }
    }
    private fun makeQr(text:String):Bitmap{
        val m=MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,650,650)
        val b=Bitmap.createBitmap(650,650,Bitmap.Config.RGB_565)
        for(x in 0 until 650)for(y in 0 until 650)b.setPixel(x,y,if(m[x,y])Color.BLACK else Color.WHITE)
        return b
    }
}
