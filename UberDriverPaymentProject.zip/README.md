# Uber Driver Payment
UPI: 8116295714-7@ybl
Remark: Uber
Payment Done saves the transaction locally and attempts to open Uber Driver.
