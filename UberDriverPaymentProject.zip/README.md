# Driver Pay v2
Professional UPI collection UI for drivers.
UPI: 8116295714-7@ybl
Fixed remark: Uber
Includes quick amounts, QR generation, local payment history, reports, and Uber Driver launch.
